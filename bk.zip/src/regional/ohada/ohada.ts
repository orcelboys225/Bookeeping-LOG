import { Fyo } from 'fyo';
import { ModelNameEnum } from 'models/types';
import {
  isOhadaCountryCode,
  isZeroDecimalCurrency,
  OHADA_STANDARD_VAT,
} from 'utils/ohada';
import ohadaCOA from '../../../fixtures/verified/ohada.json';

type OhadaDefaults = typeof ohadaCOA.defaults;

/**
 * Initialisation spécifique SYSCOHADA, exécutée à la création d'une société
 * pour un pays membre de l'OHADA (après la création du plan comptable) :
 *  - comptes par défaut (écarts d'arrondi, créances irrécouvrables, remises),
 *  - TVA collectée / déductible aux taux du pays,
 *  - précision d'affichage à 0 décimale pour le franc CFA.
 *
 * Si le plan comptable choisi n'est pas le SYSCOHADA (compte 4111 absent),
 * rien n'est modifié.
 */
export async function createOhadaRecords(fyo: Fyo, countryCode: string) {
  if (!isOhadaCountryCode(countryCode)) {
    return;
  }

  const defaults = ohadaCOA.defaults as OhadaDefaults;
  if (!(await fyo.db.exists(ModelNameEnum.Account, defaults.receivable))) {
    return;
  }

  await setAccountingDefaults(fyo, defaults);
  await createVatTaxes(fyo, countryCode, defaults);
  await setCurrencyPrecision(fyo);
}

async function setAccountingDefaults(fyo: Fyo, defaults: OhadaDefaults) {
  const settings = fyo.singles.AccountingSettings!;
  await settings.set('writeOffAccount', defaults.writeOff);
  await settings.set('roundOffAccount', defaults.roundOff);
  await settings.set('discountAccount', defaults.discount);
  await settings.sync();
}

function formatRate(rate: number) {
  return String(rate).replace('.', ',');
}

async function createVatTaxes(
  fyo: Fyo,
  countryCode: string,
  defaults: OhadaDefaults
) {
  const standard = OHADA_STANDARD_VAT[countryCode];
  const rates = [...new Set([standard, 0].filter((r) => r !== undefined))];

  for (const rate of rates) {
    const label = rate === 0 ? 'Exonéré (0%)' : `${formatRate(rate)}%`;
    const taxes = [
      { name: `TVA collectée ${label}`, account: defaults.taxCollected },
      { name: `TVA déductible ${label}`, account: defaults.taxDeductible },
    ];

    for (const { name, account } of taxes) {
      if (await fyo.db.exists(ModelNameEnum.Tax, name)) {
        continue;
      }

      const tax = fyo.doc.getNewDoc(ModelNameEnum.Tax, {
        name,
        details: [{ account, rate }],
      });
      await tax.sync();
    }
  }
}

async function setCurrencyPrecision(fyo: Fyo) {
  const currency = fyo.singles.SystemSettings?.currency as string | undefined;
  if (!isZeroDecimalCurrency(currency)) {
    return;
  }

  await fyo.singles.SystemSettings!.setAndSync('displayPrecision', 0);
}
