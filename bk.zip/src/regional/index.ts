import { Fyo } from 'fyo';
import { getCountryCodeFromCountry } from 'utils/misc';
import { isOhadaCountryCode } from 'utils/ohada';
import { createIndianRecords } from './in/in';
import { createOhadaRecords } from './ohada/ohada';

export async function createRegionalRecords(country: string, fyo: Fyo) {
  if (country === 'India') {
    await createIndianRecords(fyo);
  }

  const countryCode = getCountryCodeFromCountry(country);
  if (isOhadaCountryCode(countryCode)) {
    await createOhadaRecords(fyo, countryCode);
  }

  return;
}
