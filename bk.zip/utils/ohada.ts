/**
 * Données spécifiques à l'espace OHADA (SYSCOHADA révisé).
 *
 * Ce fichier est agnostique (utilisable côté client et serveur) : il ne doit
 * importer aucun module dépendant de la plateforme.
 */

/** Intitulé du plan comptable tel qu'affiché dans l'assistant de configuration. */
export const OHADA_COA_NAME = 'SYSCOHADA révisé - Plan comptable OHADA';

/** Code utilisé pour retrouver `fixtures/verified/ohada.json`. */
export const OHADA_COA_CODE = 'ohada';

/**
 * États membres de l'OHADA (code ISO 3166-1 alpha-2).
 */
export const OHADA_COUNTRY_CODES = [
  'bj', // Bénin
  'bf', // Burkina Faso
  'cm', // Cameroun
  'cf', // Centrafrique
  'km', // Comores
  'cg', // Congo
  'ci', // Côte d'Ivoire
  'ga', // Gabon
  'gn', // Guinée
  'gw', // Guinée-Bissau
  'gq', // Guinée équatoriale
  'ml', // Mali
  'ne', // Niger
  'cd', // République démocratique du Congo
  'sn', // Sénégal
  'td', // Tchad
  'tg', // Togo
] as const;

export function isOhadaCountryCode(code?: string): boolean {
  return !!code && (OHADA_COUNTRY_CODES as readonly string[]).includes(code);
}

/**
 * Devises sans subdivision d'usage : les montants s'expriment en unités entières.
 * (Le franc CFA n'a pas de centimes en pratique.)
 */
const ZERO_DECIMAL_CURRENCIES = ['XOF', 'XAF', 'KMF', 'GNF'];

export function isZeroDecimalCurrency(currency?: string): boolean {
  return !!currency && ZERO_DECIMAL_CURRENCIES.includes(currency);
}

/**
 * Correctifs appliqués à `fixtures/countryInfo.json` pour les pays OHADA :
 * - exercice comptable = année civile (1er janvier - 31 décembre),
 * - locales françaises (lisibilité des montants et des dates),
 * - devise de la RDC (absente du fichier d'origine).
 */
export const OHADA_COUNTRY_OVERRIDES: Record<string, Record<string, unknown>> = {
  'Congo, The Democratic Republic of the': {
    currency: 'CDF',
    currency_name: 'Congolese Franc',
    currency_symbol: 'FC',
    currency_fraction: 'Centime',
    currency_fraction_units: 100,
    timezones: ['Africa/Kinshasa'],
  },
  Mali: { locale: 'fr-ML' },
  Togo: { locale: 'fr-TG' },
  'Guinea-Bissau': { locale: 'fr-FR' },
};

export function applyOhadaOverrides<T extends Record<string, unknown>>(
  info: T
): T {
  const result: Record<string, unknown> = { ...info };
  for (const [country, value] of Object.entries(info)) {
    const code = (value as { code?: string } | undefined)?.code;
    if (!isOhadaCountryCode(code)) {
      continue;
    }

    result[country] = {
      ...(value as object),
      fiscal_year_start: '01-01',
      fiscal_year_end: '12-31',
      date_format: 'dd/MM/yyyy',
      ...(OHADA_COUNTRY_OVERRIDES[country] ?? {}),
    };
  }

  return result as T;
}

/**
 * Taux normaux de TVA par pays (en %). Ces taux sont indicatifs : ils sont
 * créés à l'installation et restent modifiables par l'utilisateur. Vérifier
 * auprès de l'administration fiscale du pays avant utilisation.
 */
export const OHADA_STANDARD_VAT: Record<string, number> = {
  bj: 18,
  bf: 18,
  cm: 19.25,
  cf: 19,
  km: 10,
  cg: 18,
  ci: 18,
  ga: 18,
  gn: 18,
  gw: 15,
  gq: 15,
  ml: 18,
  ne: 19,
  cd: 16,
  sn: 18,
  td: 18,
  tg: 18,
};
