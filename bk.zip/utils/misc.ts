import { DateTime } from 'luxon';
import countryInfo from '../fixtures/countryInfo.json';
import { CUSTOM_EVENTS } from './messages';
import { applyOhadaOverrides } from './ohada';
import { CountryInfoMap, UnexpectedLogObject } from './types';

let patchedCountryInfo: CountryInfoMap | undefined;

export function getCountryInfo(): CountryInfoMap {
  // Pays OHADA : exercice = année civile, locales françaises, devise RDC.
  patchedCountryInfo ??= applyOhadaOverrides(
    // @ts-ignore
    countryInfo as unknown as Record<string, unknown>
  ) as unknown as CountryInfoMap;
  return patchedCountryInfo;
}

export function getCountryCodeFromCountry(countryName: string): string {
  const countryInfoMap = getCountryInfo();
  const countryInfo = countryInfoMap[countryName];
  if (countryInfo === undefined) {
    return '';
  }

  return countryInfo.code;
}

export function getFiscalYear(
  date: string,
  isStart: boolean
): undefined | Date {
  if (!date) {
    return undefined;
  }

  const today = DateTime.local().startOf('day');
  const dateTime = DateTime.fromFormat(date, 'MM-dd');
  if (isStart) {
    // Début de l'exercice en cours : la dernière occurrence de cette date
    // qui n'est pas dans le futur (1er janvier pour l'année civile OHADA).
    return (dateTime > today ? dateTime.minus({ years: 1 }) : dateTime).toJSDate();
  }

  // Fin de l'exercice en cours : la prochaine occurrence de cette date.
  return (dateTime < today ? dateTime.plus({ years: 1 }) : dateTime).toJSDate();
}

export function logUnexpected(detail: Partial<UnexpectedLogObject>) {
  /**
   * Raises a custom event, it's lsitener is in renderer.ts
   * used to log unexpected occurances as errors.
   */
  if (!window?.CustomEvent) {
    return;
  }

  detail.name ??= 'LogUnexpected';
  detail.message ??= 'Logging an unexpected occurance';
  detail.stack ??= new Error().stack;
  detail.more ??= {};

  const event = new window.CustomEvent(CUSTOM_EVENTS.LOG_UNEXPECTED, {
    detail,
  });
  window.dispatchEvent(event);
}
