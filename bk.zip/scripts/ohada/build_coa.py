#!/usr/bin/env python3
"""
Génère fixtures/verified/ohada.json (plan comptable SYSCOHADA révisé)
à partir de scripts/ohada/coa_data.txt.

Usage :  python3 scripts/ohada/build_coa.py

Règles :
- Chaque compte est rattaché au compte parent le plus proche (préfixe le plus long)
  de même nature ; à défaut, au nœud racine de sa nature et de sa classe.
- La nature (Actif/Passif/Capitaux propres/Produit/Charge) vient de la table
  DEFAULT_NATURE (2 premiers chiffres) ou de l'option R= de la ligne.
"""
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE.parent.parent / "fixtures" / "verified" / "ohada.json"

ROOT_TYPE = {"A": "Asset", "L": "Liability", "E": "Equity", "I": "Income", "X": "Expense"}

# nature par défaut selon les deux premiers chiffres du compte
DEFAULT_NATURE = {}
for p in ("10", "11", "12", "13", "14", "15"):
    DEFAULT_NATURE[p] = "E"
for p in ("16", "17", "18", "19"):
    DEFAULT_NATURE[p] = "L"
for p in ("20", "21", "22", "23", "24", "25", "26", "27", "28", "29"):
    DEFAULT_NATURE[p] = "A"
for p in ("31", "32", "33", "34", "35", "36", "37", "38", "39"):
    DEFAULT_NATURE[p] = "A"
for p in ("40", "42", "43", "44", "45", "46", "47", "48"):
    DEFAULT_NATURE[p] = "L"
DEFAULT_NATURE["41"] = "A"
DEFAULT_NATURE["49"] = "A"
for p in ("50", "51", "52", "53", "54", "55", "57", "58", "59"):
    DEFAULT_NATURE[p] = "A"
DEFAULT_NATURE["56"] = "L"
for p in ("60", "61", "62", "63", "64", "65", "66", "67", "68", "69"):
    DEFAULT_NATURE[p] = "X"
for p in ("70", "71", "72", "73", "75", "77", "78", "79"):
    DEFAULT_NATURE[p] = "I"
for p in ("81", "83", "85", "87", "89"):
    DEFAULT_NATURE[p] = "X"
for p in ("82", "84", "86", "88"):
    DEFAULT_NATURE[p] = "I"

# nœuds racines : (clé nature, classe) -> libellé
ROOT_LABELS = {
    ("E", "1"): "1 - Capitaux propres et ressources assimilées",
    ("L", "1"): "1 - Dettes financières et ressources assimilées",
    ("A", "2"): "2 - Actif immobilisé",
    ("A", "3"): "3 - Stocks et en-cours",
    ("A", "4"): "4 - Comptes de tiers (soldes débiteurs)",
    ("L", "4"): "4 - Comptes de tiers (soldes créditeurs)",
    ("A", "5"): "5 - Trésorerie - Actif",
    ("L", "5"): "5 - Trésorerie - Passif",
    ("X", "6"): "6 - Charges des activités ordinaires",
    ("I", "7"): "7 - Produits des activités ordinaires",
    ("X", "8"): "8 - Autres charges (HAO)",
    ("I", "8"): "8 - Autres produits (HAO)",
}

# comptes à utiliser comme valeurs par défaut dans l'application
DEFAULT_ACCOUNTS = {
    "receivable": "4111",
    "payable": "4011",
    "incomeProduct": "7011",
    "incomeService": "706",
    "writeOff": "6511",
    "roundOff": "6588",
    "discount": "7019",
    "stockInHand": "311",
    "stockReceivedButNotBilled": "4081",
    "costOfGoodsSold": "6011",
    "taxCollected": "4431",
    "taxDeductible": "4452",
}


def parse():
    rows = []
    for n, raw in enumerate((HERE / "coa_data.txt").read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split("|")
        if len(parts) != 3:
            sys.exit(f"ligne {n} invalide : {raw}")
        code, label, opts = parts
        if not code.isdigit():
            sys.exit(f"ligne {n} : code non numérique {code}")
        o = {}
        for item in filter(None, opts.split(",")):
            k, v = item.split("=", 1)
            o[k] = v
        nature = o.get("R") or DEFAULT_NATURE.get(code[:2])
        if nature is None:
            sys.exit(f"ligne {n} : nature inconnue pour {code}")
        rows.append({"code": code, "label": label, "nature": nature, "type": o.get("T")})
    return rows


def main():
    rows = parse()
    codes = {}
    for r in rows:
        if r["code"] in codes:
            sys.exit(f"code en double : {r['code']}")
        codes[r["code"]] = r
        r["key"] = f"{r['code']} - {r['label']}"

    # nœuds racines utilisés (ordre stable)
    tree = {}
    for (nat, cls), label in ROOT_LABELS.items():
        tree[label] = {"rootType": ROOT_TYPE[nat]}
    node_of = {}

    def find_parent(r):
        code = r["code"]
        for ln in range(len(code) - 1, 0, -1):
            p = codes.get(code[:ln])
            if p and p["nature"] == r["nature"] and p["code"] in node_of:
                return node_of[p["code"]]
        return tree[ROOT_LABELS[(r["nature"], code[0])]]

    for r in rows:
        parent = find_parent(r)
        node = {}
        if r["type"]:
            node["accountType"] = r["type"]
        parent[r["key"]] = node
        node_of[r["code"]] = node

    # retirer les racines vides
    for label in list(tree):
        if len(tree[label]) == 1:
            del tree[label]

    # rootType doit venir en dernier pour garder l'ordre lisible des comptes
    for label, root in tree.items():
        rt = root.pop("rootType")
        root["rootType"] = rt

    defaults = {}
    for k, code in DEFAULT_ACCOUNTS.items():
        if code not in codes:
            sys.exit(f"compte par défaut absent : {code}")
        defaults[k] = codes[code]["key"]

    out = {
        "countryCode": "ohada",
        "name": "SYSCOHADA révisé - Plan comptable OHADA",
        "defaults": defaults,
        "tree": tree,
    }
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"{len(rows)} comptes -> {OUT}")


if __name__ == "__main__":
    main()
