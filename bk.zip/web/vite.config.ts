import vue from '@vitejs/plugin-vue';
import path from 'path';
import { defineConfig } from 'vite';
import { nodePolyfills } from 'vite-plugin-node-polyfills';

const root = path.resolve(__dirname, '..');
const polyfills = () =>
  nodePolyfills({
    include: ['events', 'util', 'buffer', 'process', 'path', 'stream', 'os'],
    globals: { Buffer: true, global: true, process: true },
  });

/**
 * Build web statique (hébergeable gratuitement) : `npm run build` → web/dist.
 * Lancer depuis la racine du projet (tailwind lit colors.json depuis le cwd).
 */
export default defineConfig({
  root: __dirname,
  base: './',
  plugins: [vue(), polyfills()],
  worker: { format: 'es', plugins: () => [polyfills()] },
  build: { outDir: path.resolve(__dirname, 'dist'), emptyOutDir: true, target: 'es2022' },
  server: { fs: { allow: [root] } },
  resolve: {
    alias: [
      // Remplacements des modules natifs / Node
      { find: 'better-sqlite3', replacement: path.resolve(__dirname, 'src/worker/sqljsDriver.ts') },
      { find: 'fs-extra', replacement: path.resolve(__dirname, 'shims/fs-extra.ts') },
      { find: 'fs/promises', replacement: path.resolve(__dirname, 'shims/fs-promises.ts') },
      { find: /^fs$/, replacement: path.resolve(__dirname, 'shims/fs.ts') },
      { find: 'electron-store', replacement: path.resolve(__dirname, 'shims/empty.ts') },
      { find: 'vue', replacement: 'vue/dist/vue.esm-bundler.js' },
      // Alias du projet (identiques à build/scripts/build.mjs)
      ...['fyo', 'src', 'schemas', 'backend', 'models', 'utils', 'regional', 'reports', 'dummy', 'fixtures'].map(
        (name) => ({ find: new RegExp(`^${name}(/|$)`), replacement: `${path.join(root, name)}$1` })
      ),
    ],
  },
});
