import './ipc'; // doit être évalué avant l'application (définit window.ipc)

// Langue par défaut : français.
try {
  if (localStorage.getItem('cfg:language') === null) {
    localStorage.setItem('cfg:language', JSON.stringify('French'));
  }
} catch {}

// Demande un stockage persistant pour éviter l'éviction des données par le navigateur.
void navigator.storage?.persist?.();

async function boot() {
  // Une seule fenêtre à la fois : deux onglets écrasent mutuellement la base.
  if (navigator.locks) {
    const free = await new Promise<boolean>((resolve) => {
      void navigator.locks.request(
        'compta-ohada-app',
        { ifAvailable: true },
        (lock) => {
          resolve(!!lock);
          return lock ? new Promise<void>(() => {}) : undefined;
        }
      );
    });
    if (!free) {
      document.body.innerHTML =
        '<p style="font:16px sans-serif;padding:2rem">Compta OHADA est déjà ouvert dans un autre onglet. Fermez-le puis rechargez cette page.</p>';
      return;
    }
  }

  await import('../../src/renderer');
}

void boot();
