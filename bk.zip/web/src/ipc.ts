/**
 * Version web de `window.ipc` (voir main/preload.ts) : l'interface continue
 * de croire qu'elle tourne dans Electron, mais tout s'exécute dans le navigateur.
 */
import { parseCSV } from 'utils/csvParser';
import { rpc, rpcData } from './dbClient';

type Json = unknown;
const KEY = (k: string) => `cfg:${k}`;

const store = {
  get(key: string): Json {
    try {
      const raw = localStorage.getItem(KEY(key));
      return raw === null ? undefined : JSON.parse(raw);
    } catch {
      return undefined;
    }
  },
  set(key: string, value: Json) {
    try {
      localStorage.setItem(KEY(key), JSON.stringify(value));
    } catch {}
  },
  delete(key: string) {
    try {
      localStorage.removeItem(KEY(key));
    } catch {}
  },
};

function download(data: BlobPart, filename: string, type = 'application/octet-stream') {
  const url = URL.createObjectURL(new Blob([data], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

function pickFile(accept?: string): Promise<File | null> {
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    if (accept) input.accept = accept;
    input.onchange = () => resolve(input.files?.[0] ?? null);
    input.oncancel = () => resolve(null);
    input.click();
  });
}

const baseName = (p: string) => p.split(/[\\/]/).pop() ?? p;

function printHtml(html: string): Promise<boolean> {
  return new Promise((resolve) => {
    const iframe = document.createElement('iframe');
    iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0';
    iframe.srcdoc = html;
    iframe.onload = () => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      setTimeout(() => iframe.remove(), 60_000);
      resolve(true);
    };
    document.body.appendChild(iframe);
  });
}

const templateFiles = import.meta.glob('../../templates/*.template.html', {
  query: '?raw',
  import: 'default',
  eager: true,
}) as Record<string, string>;
const buildTime = new Date().toISOString();

const translationFiles = import.meta.glob('../../translations/*.csv', {
  query: '?raw',
  import: 'default',
}) as Record<string, () => Promise<string>>;

const noop = () => {};

const ipc = {
  desktop: false,
  web: true,

  reloadWindow: () => location.reload(),
  minimizeWindow: noop,
  toggleMaximize: noop,
  isMaximized: async () => false,
  isFullscreen: async () => false,
  closeWindow: noop,

  async getCreds() {
    return { errorLogUrl: '', tokenString: '', telemetryUrl: '' };
  },

  async getLanguageMap(code: string) {
    const loader = translationFiles[`../../translations/${code}.csv`];
    if (!loader) {
      return { languageMap: {}, success: false, message: `Traduction introuvable : ${code}` };
    }
    const languageMap: Record<string, { translation: string; context?: string }> = {};
    for (const row of parseCSV(await loader())) {
      if (!row[0] || !row[1]) continue;
      languageMap[row[0]] = { translation: row[1] };
      if (row[3]?.length) languageMap[row[0]].context = row[3];
    }
    return { languageMap, success: true, message: '' };
  },

  async getTemplates(posTemplateWidth?: number) {
    return Object.entries(templateFiles).map(([path, template]) => {
      const file = baseName(path);
      const isPOS = file.split('-')[1]?.split('.')[0] === 'POS';
      return {
        template,
        file,
        modified: buildTime,
        width: isPOS ? posTemplateWidth ?? 0 : 0,
        height: isPOS ? 22 : 0,
      };
    });
  },

  async initScheduler() {},

  async selectFile(options: { filters?: { extensions: string[] }[] }) {
    const ext = options?.filters?.flatMap((f) => f.extensions.map((e) => `.${e}`)).join(',');
    const file = await pickFile(ext);
    if (!file) {
      return { name: '', filePath: '', success: false, data: new Uint8Array(), canceled: true };
    }
    return {
      name: file.name,
      filePath: file.name,
      success: true,
      data: new Uint8Array(await file.arrayBuffer()),
      canceled: false,
    };
  },

  async getSaveFilePath(options: { defaultPath?: string }) {
    return { canceled: false, filePath: options?.defaultPath ?? 'export' };
  },

  /** Import d'une société : le fichier .db choisi est copié dans le stockage du navigateur. */
  async getOpenFilePath() {
    const file = await pickFile('.db');
    if (!file) return { canceled: true, filePaths: [] as string[] };
    let path = file.name;
    if (await rpcData<boolean>('fs:exists', path)) {
      path = `${path.replace(/(\.books)?\.db$/, '')}_${Date.now()}.books.db`;
    }
    await rpcData('fs:import', path, new Uint8Array(await file.arrayBuffer()));
    return { canceled: false, filePaths: [path] };
  },

  async checkDbAccess(path: string) {
    return path === ':memory:' || (await rpcData<boolean>('fs:exists', path));
  },

  async checkForUpdates() {},
  openLink: (url: string) => void window.open(url, '_blank', 'noopener'),
  openExternalUrl: (url: string) => void window.open(url, '_blank', 'noopener'),

  async deleteFile(path: string) {
    return rpc('fs:delete', path);
  },

  async saveData(data: string, savePath: string) {
    download(data, baseName(savePath), 'text/plain;charset=utf-8');
  },

  showItemInFolder: noop,

  async makePDF(html: string) {
    // Dans le navigateur : boîte d'impression → « Enregistrer au format PDF ».
    return printHtml(html);
  },
  async printDocument(html: string) {
    return printHtml(html);
  },

  async getDbList() {
    const files = ((store.get('files') as { dbPath: string }[]) ?? []);
    const stored = await rpcData<{ path: string; modified: number }[]>('fs:list');
    const modified = new Map(stored.map((f) => [f.path, f.modified]));
    const alive = files.filter((f) => modified.has(f.dbPath));
    store.set('files', alive);
    return alive.map((f) => ({
      ...f,
      modified: new Date(modified.get(f.dbPath)!).toISOString(),
    }));
  },

  async getDbDefaultPath(companyName: string) {
    const safe = companyName.replace(/[\\/:*?"<>|]/g, '_').trim() || 'societe';
    let path = `${safe}.books.db`;
    if (await rpcData<boolean>('fs:exists', path)) {
      path = `${safe}_${new Date().toISOString().replace(/\D/g, '').slice(0, 14)}.books.db`;
    }
    return path;
  },

  /** Web uniquement : télécharge le fichier SQLite d'une société (sauvegarde). */
  async exportDb(path: string) {
    const bytes = await rpcData<Uint8Array | undefined>('fs:export', path);
    if (bytes) download(bytes, path);
  },

  async getEnv() {
    return { isDevelopment: false, platform: 'linux', version: '0.37.0-ohada' };
  },

  async showError(title: string, content: string) {
    alert(`${title}\n\n${content}`);
  },
  async sendError(body: string) {
    console.error(body);
  },
  async sendAPIRequest(endpoint: string, options?: RequestInit) {
    const res = await fetch(endpoint, options);
    return (await res.json()) as never;
  },

  registerMainProcessErrorListener: noop,
  registerTriggerFrontendActionListener: noop,
  registerConsoleLogListener: noop,

  db: {
    getSchema: () => rpc('db:schema'),
    create: (path: string, cc?: string) => rpc('db:create', path, cc),
    connect: (path: string, cc?: string) => rpc('db:connect', path, cc),
    call: (method: string, ...args: unknown[]) => rpc('db:call', method, ...args),
    bespoke: (method: string, ...args: unknown[]) => rpc('db:bespoke', method, ...args),
  },

  store,
};

(window as unknown as { ipc: typeof ipc }).ipc = ipc;

// Écrit la base avant de quitter l'onglet.
const flush = () => void rpc('fs:flush');
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') flush();
});
window.addEventListener('pagehide', flush);

export default ipc;
