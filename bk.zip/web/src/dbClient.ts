/** Client du Web Worker de base de données (équivalent du canal IPC Electron). */
export interface BackendResponse {
  data?: unknown;
  error?: { name: string; message: string; stack?: string };
}

const worker = new Worker(new URL('./worker/db.worker.ts', import.meta.url), {
  type: 'module',
});

let seq = 0;
const pending = new Map<number, (r: BackendResponse) => void>();
worker.onmessage = (e: MessageEvent<BackendResponse & { id: number }>) => {
  pending.get(e.data.id)?.(e.data);
  pending.delete(e.data.id);
};

export function rpc(method: string, ...args: unknown[]): Promise<BackendResponse> {
  return new Promise((resolve) => {
    const id = ++seq;
    pending.set(id, resolve);
    worker.postMessage({ id, method, args });
  });
}

/** Variante qui lève l'erreur au lieu de la renvoyer. */
export async function rpcData<T>(method: string, ...args: unknown[]): Promise<T> {
  const res = await rpc(method, ...args);
  if (res.error) throw Object.assign(new Error(res.error.message), res.error);
  return res.data as T;
}
