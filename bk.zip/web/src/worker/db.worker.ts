/// <reference lib="webworker" />
import DatabaseCore from 'backend/database/core';
import databaseManager from 'backend/database/manager';
import { ClientSqlJs } from './knexClient';
import { flushAll } from './sqljsDriver';
import { deleteFile, fileExists, listFiles, loadFile, saveFile } from './storage';

DatabaseCore.clientOverride = ClientSqlJs as never;

type Handler = (...args: any[]) => unknown;

const handlers: Record<string, Handler> = {
  'db:schema': () => databaseManager.getSchemaMap(),
  'db:create': (path: string, cc: string) =>
    databaseManager.createNewDatabase(path, cc),
  'db:connect': (path: string, cc?: string) =>
    databaseManager.connectToDatabase(path, cc),
  'db:call': (method: never, ...args: unknown[]) =>
    databaseManager.call(method, ...args),
  'db:bespoke': (method: string, ...args: unknown[]) =>
    databaseManager.callBespoke(method, ...args),

  'fs:list': () => listFiles(),
  'fs:exists': (path: string) => fileExists(path),
  'fs:delete': (path: string) => deleteFile(path),
  'fs:flush': () => flushAll(),
  'fs:import': async (path: string, bytes: Uint8Array) => {
    await saveFile(path, bytes);
    return path;
  },
  'fs:export': async (path: string) => {
    await flushAll();
    return (await loadFile(path))?.bytes;
  },
};

self.onmessage = async (e: MessageEvent<{ id: number; method: string; args: unknown[] }>) => {
  const { id, method, args } = e.data;
  try {
    const fn = handlers[method];
    if (!fn) throw new Error(`Méthode inconnue : ${method}`);
    self.postMessage({ id, data: await fn(...args) });
  } catch (err) {
    const { name, message, stack } = err as Error;
    self.postMessage({ id, error: { name, message, stack } });
  }
};
