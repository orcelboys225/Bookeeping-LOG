/**
 * Adaptateur : expose une API compatible `better-sqlite3` (celle que le
 * dialecte knex utilise) au-dessus de sql.js (SQLite compilé en WebAssembly).
 *
 * Persistance : la base vit en mémoire ; après chaque écriture elle est
 * exportée (debounce) vers IndexedDB. L'export est différé tant qu'une
 * transaction est ouverte.
 */
import initSqlJs from 'sql.js';
import type { Database as SqlJsDb, SqlJsStatic } from 'sql.js';
import wasmUrl from 'sql.js/dist/sql-wasm.wasm?url';
import { loadFile, saveFile } from './storage';

let SQL: SqlJsStatic | undefined;
export async function getSql() {
  SQL ??= await initSqlJs({ locateFile: () => wasmUrl });
  return SQL;
}

type Bindable = number | string | null | Uint8Array;

function normalize(bindings: unknown): Bindable[] {
  const list = Array.isArray(bindings)
    ? bindings
    : bindings === undefined || bindings === null
    ? []
    : [bindings];
  return list.map((v) => {
    if (v === undefined || v === null) return null;
    if (typeof v === 'boolean') return v ? 1 : 0;
    if (typeof v === 'bigint') return Number(v);
    if (v instanceof Date) return v.getTime();
    return v as Bindable;
  });
}

const SAVE_DELAY_MS = 800;
const registry = new Map<string, SqlJsConnection>();

export class SqlJsConnection {
  inTx = false;
  dirty = false;
  private timer: ReturnType<typeof setTimeout> | undefined;

  constructor(readonly filename: string, readonly db: SqlJsDb) {
    registry.set(filename, this);
  }

  static async open(filename: string): Promise<SqlJsConnection> {
    const sql = await getSql();
    const stored = filename === ':memory:' ? undefined : await loadFile(filename);
    const db = new sql.Database(stored?.bytes);
    return new SqlJsConnection(filename, db);
  }

  prepare(sql: string) {
    return new Statement(this, sql);
  }

  exec(sql: string) {
    this.track(sql);
    this.db.exec(sql);
    this.touch(sql);
  }

  pragma(sql: string) {
    return this.db.exec(`PRAGMA ${sql}`);
  }

  track(sql: string) {
    const s = sql.trim().toLowerCase();
    if (s.startsWith('begin')) this.inTx = true;
    else if (s.startsWith('commit') || s.startsWith('end')) this.inTx = false;
    else if (s.startsWith('rollback') && !s.startsWith('rollback to')) {
      this.inTx = false;
    }
  }

  touch(sql: string) {
    if (/^\s*pragma/i.test(sql) || this.filename === ':memory:') return;
    this.dirty = true;
    clearTimeout(this.timer);
    this.timer = setTimeout(() => void this.flush().catch(console.error), SAVE_DELAY_MS);
  }

  async flush() {
    clearTimeout(this.timer);
    if (!this.dirty || this.filename === ':memory:') return;
    while (this.inTx) {
      await new Promise((r) => setTimeout(r, 50));
    }
    // db.export() ferme/rouvre la base : PRAGMA à rétablir (même tick, sans await).
    const bytes = this.db.export();
    this.db.exec('PRAGMA foreign_keys = ON');
    this.dirty = false;
    await saveFile(this.filename, bytes);
  }

  /** Copie de sauvegarde (utilisée par le gestionnaire de migrations). */
  async backup(path: string) {
    await saveFile(path, this.db.export());
    this.db.exec('PRAGMA foreign_keys = ON');
  }

  async close() {
    await this.flush();
    this.db.close();
    if (registry.get(this.filename) === this) registry.delete(this.filename);
  }
}

class Statement {
  readonly reader: boolean;
  private stmt;

  constructor(private conn: SqlJsConnection, private sql: string) {
    this.stmt = conn.db.prepare(sql);
    this.reader = this.stmt.getColumnNames().length > 0;
  }

  all(bindings?: unknown) {
    const rows: Record<string, unknown>[] = [];
    try {
      this.stmt.bind(normalize(bindings));
      while (this.stmt.step()) rows.push(this.stmt.getAsObject());
    } finally {
      this.stmt.free();
    }
    return rows;
  }

  run(bindings?: unknown) {
    this.conn.track(this.sql);
    try {
      this.stmt.run(normalize(bindings));
    } finally {
      this.stmt.free();
    }
    const changes = this.conn.db.getRowsModified();
    let lastInsertRowid = 0;
    if (/^\s*(insert|replace)/i.test(this.sql)) {
      lastInsertRowid = Number(
        this.conn.db.exec('SELECT last_insert_rowid()')[0]?.values[0]?.[0] ?? 0
      );
    }
    this.conn.touch(this.sql);
    return { changes, lastInsertRowid };
  }
}

export async function flushAll() {
  await Promise.all([...registry.values()].map((c) => c.flush()));
}

/** Équivalent de `BetterSQLite3(path, { readonly: true })` pour les sauvegardes. */
export default function Database(filename: string) {
  const conn = registry.get(filename);
  return {
    backup: (path: string) => conn?.backup(path) ?? Promise.resolve(),
    close() {},
  };
}
