/**
 * Stockage des fichiers société (.books.db) dans IndexedDB.
 * Utilisé uniquement depuis le Web Worker de base de données.
 */
const DB_NAME = 'compta-ohada';
const STORE = 'files';

export interface StoredFile {
  bytes: Uint8Array;
  modified: number;
}

let dbPromise: Promise<IDBDatabase> | undefined;

function open(): Promise<IDBDatabase> {
  dbPromise ??= new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

async function tx<T>(
  mode: IDBTransactionMode,
  fn: (store: IDBObjectStore) => IDBRequest<T>
): Promise<T> {
  const db = await open();
  return new Promise((resolve, reject) => {
    const req = fn(db.transaction(STORE, mode).objectStore(STORE));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function loadFile(path: string): Promise<StoredFile | undefined> {
  return (await tx('readonly', (s) => s.get(path))) as StoredFile | undefined;
}

export async function saveFile(path: string, bytes: Uint8Array) {
  await tx('readwrite', (s) => s.put({ bytes, modified: Date.now() }, path));
}

export async function deleteFile(path: string) {
  await tx('readwrite', (s) => s.delete(path));
}

export async function fileExists(path: string) {
  return (await tx('readonly', (s) => s.count(path))) > 0;
}

export async function listFiles(): Promise<{ path: string; modified: number }[]> {
  const db = await open();
  return new Promise((resolve, reject) => {
    const out: { path: string; modified: number }[] = [];
    const req = db.transaction(STORE, 'readonly').objectStore(STORE).openCursor();
    req.onsuccess = () => {
      const cursor = req.result;
      if (!cursor) {
        return resolve(out);
      }
      const key = String(cursor.key);
      if (!key.startsWith('backups/')) {
        out.push({ path: key, modified: (cursor.value as StoredFile).modified });
      }
      cursor.continue();
    };
    req.onerror = () => reject(req.error);
  });
}
