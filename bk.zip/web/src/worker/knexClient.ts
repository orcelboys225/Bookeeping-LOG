// @ts-ignore - module CommonJS interne de knex, sans typage
import Client_BetterSQLite3 from 'knex/lib/dialects/better-sqlite3/index.js';
import { SqlJsConnection } from './sqljsDriver';

/**
 * Dialecte knex "better-sqlite3" dont la connexion est servie par sql.js.
 * Les requêtes, le compilateur SQL et le schéma restent ceux de knex.
 */
export class ClientSqlJs extends (Client_BetterSQLite3 as new (c: unknown) => any) {
  _driver() {
    return class Unused {};
  }

  async acquireRawConnection() {
    const { filename } = this.connectionSettings as { filename: string };
    return SqlJsConnection.open(filename);
  }
}
