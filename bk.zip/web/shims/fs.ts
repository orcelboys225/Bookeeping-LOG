// Shim minimal de `fs` pour le navigateur (le stockage réel passe par IndexedDB).
export const constants = { R_OK: 4, W_OK: 2 };
export default { constants };
