import { deleteFile, fileExists } from '../src/worker/storage';

export async function access(path: string) {
  if (!(await fileExists(path))) {
    const err = new Error(`ENOENT: ${path}`) as Error & { code: string };
    err.code = 'ENOENT';
    throw err;
  }
}

export async function unlink(path: string) {
  await deleteFile(path);
}

export async function rename(): Promise<void> {
  throw new Error('rename non supporté dans la version web');
}

export default { access, unlink, rename };
