// Module vide : remplace les dépendances Node/natives absentes du navigateur.
export default {};
