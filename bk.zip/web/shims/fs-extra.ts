export function ensureDirSync() {}
export function ensureDir() {
  return Promise.resolve();
}
export function pathExists() {
  return Promise.resolve(false);
}
export default { ensureDirSync, ensureDir, pathExists };
